from django.urls import path,include

from . import views

app_name = "admin_panel"

urlpatterns = [
    path("info-numbers/",views.AdminInfoNumberView.as_view(),name="info_numbers"),
    path("email-campaign/<int:id>/",views.SendEmailCampaignView.as_view(),name="email-campaign"),
]