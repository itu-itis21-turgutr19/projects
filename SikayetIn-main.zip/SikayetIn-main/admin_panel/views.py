from rest_framework.views import APIView
from rest_framework import permissions
from rest_framework.response import Response
from brands.models import (
    LikeComplaints,
    Complaint,
    Comment
)

from users.serializers import InfoNumberSerializer

from commons.helpers import HelperNumberofView

from commons.send_mail import send_email_campaign,get_email_campaign_report

class AdminInfoNumberView(APIView):
    """ Admin panelinde tüm şikayetler ve yorumlar ile ilgili bilgiler """

    def get(self,request,*args,**kwargs):
        
        like_num = LikeComplaints.objects.all().count()
        complaint_num = Complaint.objects.all().count()
        comment_num = Comment.objects.all().count()

        instance = HelperNumberofView(
            like_num=like_num,
            complaint_num=complaint_num,
            comment_num=comment_num
            )
        
        serializer = InfoNumberSerializer(instance)

        return Response(serializer.data)
        
class SendEmailCampaignView(APIView):
    permission_classes = [permissions.IsAdminUser]

    def get(self,request,*args,**kwargs):
        campaign_id = kwargs.get("campaign_id")
        result = get_email_campaign_report(int(campaign_id))

        if result == "Error":
            return Response("Bir hata oluştu. Muhtemelen kampanya id bilgisi yanlış girildi")
        return result

    def post(self,request,*args,**kwargs):
        campaign_id = kwargs.get("campaign_id")

        result = send_email_campaign(int(campaign_id))

        if result == "Success":
            return Response("Kampanya Başarıyla Gönderildi")
        elif result == "Error":
            return Response("Bir hata oluştu. Muhtemelen id bilgisi yanlış verildi")
        else:
            return Response("Bilinmeyen bir hata oluştu.")
