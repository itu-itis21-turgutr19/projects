from rest_framework.views import APIView
from rest_framework import permissions
from rest_framework.response import Response

from .models import Blog
from .permissions import IsExecutiveOrReadOnly
from .serializers import BlogSerializer

#user id yunusarlivdl
#2a19496c-9bce-42a8-895b-20c972584850
class BlogView(APIView):

    permission_classes = [IsExecutiveOrReadOnly]

    def get(self,request,*args,**kwargs):
        all_blogs = Blog.objects.all().order_by("-created")

        serializer = BlogSerializer(all_blogs,many=True)

        return Response(serializer.data)

    def post(self,request,*args,**kwargs):
        data = request.data
        serializer = BlogSerializer(data=data)
        if serializer.is_valid(raise_exception=False):
            serializer.save()
            return Response(serializer.data)
        return Response("Geçersiz veri")

class BlogDetailView(APIView):

    permission_classes = [IsExecutiveOrReadOnly]

    def get(self,request,*args,**kwargs):
        blog_id = kwargs.get("blog_id")

        try:
            blog = Blog.objects.get(id=blog_id)
        except Blog.DoesNotExist:
            return Response(" Böyle bir blog bulunmamaktadır ")
        
        serializer = BlogSerializer(blog)

        return Response(serializer.data)

    def put(self,request,*args,**kwargs):
        blog_id = kwargs.get("blog_id")

        try:
            blog = Blog.objects.get(id=blog_id)
        except Blog.DoesNotExist:
            return Response(" Böyle bir blog bulunmamaktadır ")
        
        if request.user.is_blogger:
            data = request.data
            serializer = BlogSerializer(blog,data,partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            else:
                return Response("Invalid data")
        else:
            return Response("Blog Güncelleme izniniz bulunmamaktadır.")

    
    def delete(self,request,*args,**kwargs):
        blog_id = kwargs.get("blog_id")

        try:
            blog = Blog.objects.get(id=blog_id)
        except Blog.DoesNotExist:
            return Response(" Böyle bir blog bulunmamaktadır ")
        
        if request.user.is_blogger:
            blog.delete()
            return Response("Blog başarı ile silindi!")
        else:
            return Response("Blog silme izniniz bulunmamaktadır.")


class VerifyBlog(APIView):
    permission_classes = [permissions.IsAdminUser]

    def post(self,request,*args,**kwargs):
        blog_id = kwargs.get("blog_id")

        try:
            blog = Blog.objects.get(id=blog_id)
        except Blog.DoesNotExist:
            return Response("Blog bulunamadı!")
        
        blog.verified = True

        return Response("Blog Başarıyla Onaylandı!")