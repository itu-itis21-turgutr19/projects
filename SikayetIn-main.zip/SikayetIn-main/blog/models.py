from email.policy import default
from django.db import models

from users.models import User
import uuid

class Blog(models.Model):
    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )
    user = models.ForeignKey(User,on_delete=models.PROTECT)
    title = models.CharField(max_length=400,blank=False,null=False)
    text = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    read = models.PositiveBigIntegerField(default=0)
    verified = models.BooleanField(default=False)

    @property
    def is_verified(self):
        return self.verified
    
    def __str__(self):
        return self.title