from django.urls import path
from . import views

urlpatterns = [
    path("all-blogs/",views.BlogView.as_view(),name="blogs"),
    path("all-blogs/blog/<uuid:blog_id>/",views.BlogDetailView.as_view(),name="detail"),
    path("all-blogs/blog/<uuid:blog_id>/verify/",views.VerifyBlog.as_view(),name="verify"),
]