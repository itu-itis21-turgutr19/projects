import pandas
from brands.models import TemporaryExcelKeeper

class ImportFile:
    def __init__(self,file,instance) -> None:
        
        #gelen dosya => request.FILES instance olarak
        self.file = file
        #hangi veri tabanına yazılacağı
        self.instance = instance

        file_obj = TemporaryExcelKeeper.objects.create(
            file = self.file
        )
        file_obj.save()

        self.temporary_file = file_obj.file

    def read_file(self):
        """ Dosyayı okumak ve sözlük yapısına çevirmek """
        file = pandas.read_excel(self.temporary_file)
        to_dict = file.to_dict(orient="records")
        return to_dict

    def import_to_instance(self):
        """ Kayıtları ilgili veri tabanına kaydetmek """
        database = self.instance
        records = self.read_file()
        try:
            fields = database._meta.fields
            field_names = [field.name for field in fields]
            record_list = []
            for record in records:
                obj = {}
                for k in record.keys():
                    if k in field_names:
                        obj[k] = record[k]
                record_list.append(obj)
            instances = [database(**record) for record in record_list]
            database.objects.bulk_create(instances,batch_size=999999)
        except Exception as e:
            print(e)
            return "Error"
        finally:
            self.temporary_file.delete()