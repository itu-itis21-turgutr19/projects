class HelperNumberofView:
    """ Info number serializer'ı gerçelklemştirmek için yardımcı class """
    def __init__(self,like_num,comment_num,complaint_num):
        self.like_num = like_num
        self.comment_num = comment_num
        self.complaint_num = complaint_num