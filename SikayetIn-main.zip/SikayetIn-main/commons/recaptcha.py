import requests
from SikayetClone.settings import CAPTCHA_PRIVATE_KEY

def confirm_captcha(captcha_response):
    verify_url = 'https://www.google.com/recaptcha/api/siteverify'
    value = { 
        'secret': CAPTCHA_PRIVATE_KEY,
        'response': captcha_response
    }
    response = requests.post(verify_url, value) 
    result = response.json() 
    if result['success'] is True: 
        return True
    else: 
        return {'status': result['success'], 'reason': result['error-codes']}