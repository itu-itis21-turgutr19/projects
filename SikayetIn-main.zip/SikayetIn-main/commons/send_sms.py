from twilio.rest import Client

TWILIO_ACCOUNT_ID = "AC37d94415df37f4b8b57eddf8c96e4ad8"
TWILIO_AUTH_TOKEN = "6184ed23ca1d524db7b13d1b803c3865"

client = Client(TWILIO_ACCOUNT_ID,TWILIO_AUTH_TOKEN)

message = client.messages.create(         
                              messaging_service_sid='MGb899e13c4b27471060b3771a50f1ac89',
                              to='+905449313762',
                              body="hello there!"
                          ) 
 
print(message.status)
#hesap yükseltilmeli.
def send_notification_sms(phone_number,description,link):
    pass

def send_confirmation_sms(user):
    pass