from __future__ import print_function
from django.core.mail import EmailMessage
import sib_api_v3_sdk
from sib_api_v3_sdk.rest import ApiException


API_KEY = "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"


configuration = sib_api_v3_sdk.Configuration()
configuration.api_key['api-key'] = API_KEY


def send_email_campaign(id):
    """ Sending a campaign email """
    # create an instance of the API class
    # create an instance of the API class
    api_instance = sib_api_v3_sdk.EmailCampaignsApi(sib_api_v3_sdk.ApiClient(configuration))
    campaign_id = id # int | Id of the campaign

    try:
        # Send an email campaign immediately, based on campaignId
        api_instance.send_email_campaign_now(campaign_id)
    except ApiException as e:
        return "Error"

def get_email_campaign_report(id):
    """ Getting email campaign report """
    api_instance = sib_api_v3_sdk.EmailCampaignsApi(sib_api_v3_sdk.ApiClient(configuration))
    campaign_id = id # int | Id of the campaign

    try:
        # Get an email campaign report
        api_response = api_instance.get_email_campaign(campaign_id)
        return api_response
    except ApiException as e:
        return "Error"


def send_confirmation_email(email,token):   
    """ Sending email to users to verify their accounts."""
    link = f"http://127.0.0.1:8000/users/confirm-email/{token}/"
    subject = "Email Confirmation"
    recipients = [email]
    send_email = EmailMessage(subject=subject, body=link, from_email="rapor@scor-app.com",to=recipients)
    send_email.send()           


def send_reset_password_email(email,token):
    """ Sending email to users to reset their passwords """
    link = f"http://127.0.0.1:8000/users/reset-password/{token}/"
    subject = "Password Reset"
    recipients = [email]
    try:
        send_email = EmailMessage(subject=subject,body=link,from_email="rapor@scor-app.com",to=recipients)
        send_email.send()
    except:
        return False
    return True


def send_notification_email(email,description,link):
    subject = "Bildirim"
    recipients = [email]
    body = description
    body += f"Görüntülemek için {link} tıklayınız"
    try:
        send_mail = EmailMessage(subject=subject,body=link,from_email="rapor@scor-app.com",to=recipients)
        send_mail.send()
    except:
        return False
    return True