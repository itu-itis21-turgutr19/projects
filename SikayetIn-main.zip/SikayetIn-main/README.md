# SikayetIn

SikayetIn django ile yazılmış backend projesi.

## Installation

python installation package olan  [pip](https://pip.pypa.io/en/stable/) kullanılarak proje gereksinimlerini indirin.
Ilk olarak bir klasörün içerisine backend ve front-end diye iki ayrı klasör oluşturun. Daha sonra backend içerisinde bir sanal makine yaratın.
```
virtualenv env
```
Not: Python'un yüklü olduğundan ve [pip](https://pip.pypa.io/en/stable/)'in aktif olduğundan emin olun. Eğer sanal makine kütüphanesi olan virtualenv yüklü değilse
```
pip install virtualenv 
```
Ardından 
```
virtualenv env
```
diyerek sanal makineyi aktif hale getirebilirsiniz.


Daha sonra, windows için:
```
env\Scripts\activate.bat
```
Linux için:
```
source env/Scripts/activate
```
diyerek sanal makineyi aktif hale getirin.
Projenin kaynak kodlarını indirmek için:

```
git clone https://github.com/yunusarli/SikayetIn.git
```
Daha sonra requirements.txt'nin bulunduğu dizine gidin. Burada 
```
pip install -r requirements.txt
```
diyerek gerekli paketlerin indirilmesini başlatın.
Tüm bu işlemler halledildikten sonra manage.py dosyasının bulunduğu dizine gelin ve kullanımını aşağıdaki gibi başlatın.
## Usage

```
python manage.py makemigrations
```
Ardından 
```
python manage.py migrate
```
ve en son olarak
```
python manage.py runserver
```
Artık uygulama server'ı başlatılmış olur ve api endpointlerini front-end klasörünün içerisinde oluşturmuş olduğunuz projeniz ile tüketebilirsiniz.
