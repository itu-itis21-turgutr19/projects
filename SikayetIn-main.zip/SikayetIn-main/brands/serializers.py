from rest_framework import serializers
from users.models import Category
from users.serializers import UserSerializer
from .models import (
    Brand,
    Requisition,
    Comment,
    Complaint,
    NotificationSettings,
    Notification,
    LikeComplaints,
    Follow,
    Star,
    SupportTicket,
    SupportTicketAnswer,
)

class BrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brand
        fields = "__all__"

class ComplaintSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    brand = BrandSerializer(read_only=True)
    class Meta:
        model = Complaint
        fields = ["id","title","text","image","verified","created","updated","situation","user","brand"]
class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = "__all__" 

class SupportTicketAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupportTicketAnswer
        fields = "__all__"

class SupportTicketSerializer(serializers.ModelSerializer):
    class Meta:
        model = SupportTicket
        fields = "__all__"

class LikeComplaintsSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    complaint = ComplaintSerializer(read_only=True)
    class Meta:
        model = LikeComplaints
        fields = ("id","timestamp","user","complaint")

class FollowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Follow
        fields = "__all__"



class RequisitionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Requisition
        fields = "__all__"

class CommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Comment
        fields = "__all__"



class NotificationSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationSettings
        fields = "__all__"

class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = "__all__"

class StarSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    brand = BrandSerializer(read_only=True)
    class Meta:
        model = Star
        fields = ("point","user","brand")