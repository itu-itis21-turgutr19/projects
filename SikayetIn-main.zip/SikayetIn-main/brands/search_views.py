from rest_framework.views import APIView
from rest_framework import permissions
from rest_framework.response import Response

from brands.models import Brand,Category
from users.models import User

from brands.serializers import BrandSerializer,CategorySerializer
from users.serializers import UserSerializer


class SearchBrands(APIView):

    def get(self,request,*args,**kwargs):
        key = kwargs.get("key")

        all_brands = Brand.objects.filter(name__icontains=key)

        if not all_brands:
            return Response("Eşleşen bir marka bulunamadı. Tekrar denemek ister misin?")
        serializer = BrandSerializer(all_brands,many=True)

        return Response(serializer.data)

        
        


