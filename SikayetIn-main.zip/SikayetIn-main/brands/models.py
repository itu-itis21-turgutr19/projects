from django.db import models
from users.models import Category,User
import uuid
from django.db.models.signals import post_save
from django.dispatch import receiver
from commons.send_mail import send_notification_email
from commons.send_sms import send_notification_sms

class Brand(models.Model):
    """ Marka tablosu.
        Marka kendini onaylamadığı sürece admin tarafından girilen bir 
        profil ile açık kalacak ve markalar kendi markalarını almak isterlerse,
        email hesaplarını doğrulayıp talep açabilecekler

     """
    id = models.UUIDField(
        default=uuid.uuid4,
        editable=False,
        primary_key=True
    )
    brand = models.ForeignKey(User,on_delete=models.CASCADE,blank=True,null=True)
    category = models.ForeignKey(Category,on_delete=models.CASCADE,blank=True,null=True)
    name = models.CharField(max_length=255,unique=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    verified = models.BooleanField(default=False)
    logo = models.ImageField(upload_to="logos/",blank=True,null=True)
    email = models.EmailField(unique=True,blank=True,null=True)

    def __str__(self):
        return self.name
    
    @property
    def is_verified(self):
        return self.verified

class Star(models.Model):
    brand = models.ForeignKey(Brand,on_delete=models.CASCADE)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    point = models.IntegerField(default=1)

class Requisition(models.Model):
    """ 
    Sistemde kayıtlı olmayan herhangi bir marka için şikayet açmak
    isteyen kullanıcıların talepleri.
    Adminler buradan taleplere marka araştırmasından sonra markayı kurabilecekler
      """
    id = models.UUIDField(
        default=uuid.uuid4,
        primary_key=True,
        editable=False
    )
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    brand_name = models.CharField(max_length=300)
    category = models.ForeignKey(Category,on_delete=models.CASCADE,blank=True,null=True)
    title = models.CharField(max_length=255)
    text = models.TextField()
    image = models.ImageField(upload_to="requisition_images/",blank=True,null=True)
    verified = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.brand_name
    
    @property
    def is_verified(self):
        return self.verified

class Complaint(models.Model):
    """ 
        Sisteme kayıtlı olan bir marka ile ilgili şikayet açmak
    """
    id = models.UUIDField(
        default=uuid.uuid4,
        primary_key=True,
        editable=False
    )
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    brand = models.ForeignKey(Brand,on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    text = models.TextField()
    image = models.ImageField(upload_to="complaint_images/",blank=True,null=True)
    verified = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    situation = models.CharField(max_length=100,default="Çözüm Bekliyor")

    def __str__(self):
        return self.title
    
    @property
    def is_verified(self):
        return self.verified

class Comment(models.Model):
    id = models.UUIDField(
        default=uuid.uuid4,
        primary_key=True,
        editable=False
    )
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    complaint = models.ForeignKey(Complaint,on_delete=models.CASCADE)
    text = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.text[:50] + "..."


class NotificationSettings(models.Model):
    """ Kullanıcıların bildirim ayarları """
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    #telefonla bilgilendirme isteniyor mu?
    phone = models.BooleanField(default=False)
    #site içerisinde görünecek mi?
    site = models.BooleanField(default=True)
    #email ile bildirim gelecek mi?
    email = models.BooleanField(default=False)

    def __str__(self) -> str:
        return str(self.id)

    @property
    def via_phone(self):
        return self.phone
    
    @property    
    def via_site(self):
        return self.site
    @property
    def via_email(self):
        return self.email

class Notification(models.Model):
    """ Kullanıcının Bildirimlerinin Tutulacağı Alan """
    id = models.UUIDField(default=uuid.uuid4,primary_key=True,editable=False)

    user = models.ForeignKey(User,on_delete=models.CASCADE)

    description = models.TextField()

    link = models.URLField(blank=True,null=True)

    read = models.BooleanField(default=False)

    def __str__(self) -> str:
        return self.description[:50]

    @property
    def is_read(self):
        return self.read

class LikeComplaints(models.Model):
    id = models.UUIDField(
        primary_key=True,
        editable=False,
        default=uuid.uuid4
    )
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    complaint = models.ForeignKey(Complaint,on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)


    def __str__(self) -> str:
        return str(self.user.username) + "liked" + str(self.complaint.title)


class Follow(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    brand = models.ForeignKey(Brand,on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return str(self.user.username) + "started following to" + str(self.brand.name)



class SupportTicket(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    title = models.CharField(max_length=400,blank=True,null=True)
    text = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    replied = models.BooleanField(default=False)
    read = models.BooleanField(default=False)

    def __str__(self):
        return self.title
    
    @property
    def is_replied(self):
        return self.replied
    @property
    def is_read(self):
        return self.read

class SupportTicketAnswer(models.Model):
    ticket = models.ForeignKey(SupportTicket,on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    text = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title


class TemporaryExcelKeeper(models.Model):
    file = models.FileField("temporary_keeper/")

#django signals to send notifications to the users
@receiver(post_save,sender=Notification)
def send_notification_handler(sender,instance,created,*args,**kwargs):
    
    if created:
        try:
            notification_settings = NotificationSettings.objects.get(user=instance.user)
        except NotificationSettings.DoesNotExist:
            notification_settings = NotificationSettings.objects.create(user=instance.user)
            notification_settings.save()
        if notification_settings.via_email:
            send_notification_email(instance.user.email,instance.description,instance.link)
        if notification_settings.via_phone:
            send_notification_sms(instance.user.phone_number,instance.description,instance.link)