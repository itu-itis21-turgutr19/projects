from django.contrib import admin
from .models import (
    Brand,
    Requisition,
    Comment,
    Complaint,
    NotificationSettings,
    Notification,
    Follow,
    LikeComplaints,
)



admin.site.register(Brand)
admin.site.register(Requisition)
admin.site.register(Comment)
admin.site.register(Complaint)
admin.site.register(NotificationSettings)
admin.site.register(Notification)
admin.site.register(Follow)
admin.site.register(LikeComplaints)
