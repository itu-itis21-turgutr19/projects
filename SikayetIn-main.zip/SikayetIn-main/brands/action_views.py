from brands.models import Brand, Comment, Complaint, LikeComplaints, Notification, SupportTicket, SupportTicketAnswer
from brands.serializers import (
BrandSerializer,
ComplaintSerializer, 
SupportTicketSerializer,
SupportTicketAnswerSerializer,
CategorySerializer
)
from commons.helpers import HelperNumberofView
from rest_framework.views import APIView
from rest_framework import permissions
from rest_framework.response import Response
from users.models import Category, User
from users.serializers import InfoNumberSerializer
from commons.links import BASE_URL


class PopularComplaints(APIView):
    def get(self,request):
        complaints = Complaint.objects.all()[:100]
        serializer = ComplaintSerializer(complaints)
        return Response(serializer.data)

class PopularityView(APIView):
    
    def get(self,request,*args,**kwargs):
        brands = Brand.objects.all()[:100]

        serializer = BrandSerializer(brands)

        return Response(serializer.data)
    


class CategoryPopularityView(APIView):
    """ Kategoriye göre en popüler markaları verir """
    
    def get(self,request,*args,**kwargs):
        brand_id = kwargs.get("brand_id")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Marka bulunamadı")
        
        category = brand.category

        all_brands = Brand.objects.filter(category=category)[:100]

        serializer = BrandSerializer(all_brands,many=True)

        return Response(serializer.data)

class SupportTicketView(APIView):
    """ Destek biletlerinin  görüntülenmesi ve oluşturulması """

    def get(self,request,*args,**kwargs):
        user = request.user

        tickets = SupportTicket.objects.filter(user=user)

        if len(tickets) == 0:
            return Response("Henüz yardım bileti oluşturmadınız.")
        
        serializer = SupportTicketSerializer(tickets,many=True)

        return Response(serializer.data)
    
    def post(self,request,*args,**kwargs):
        user = request.user
        data = request.data

        title = data.get("title")
        text = data.get("text")

        sprt_ticket = SupportTicket.objects.create(
            user=user,
            title=title,
            text=text
        )
        sprt_ticket.save()
        
        description = f"{user.username} bir destek talebi oluşturdu"
        link = BASE_URL

        notification = Notification.objects.create(
            user = request.user,#buraya admin gelecek.
            description=description,
            link=link
        )
        notification.save()

        serializer = SupportTicketSerializer(sprt_ticket)

        return Response(serializer.data)

#support-tickets/<uuid:id>/answer/
class SupportTicketAnswerView(APIView):
    permission = [permissions.IsAdminUser]

    def post(self,request,*args,**kwargs):
        ticket_id = kwargs.get("ticket_id")
        try:
            ticket = SupportTicket.objects.get(id=ticket_id)
        except SupportTicket.DoesNotExist:
            return Response("Invalid Ticket")
        data = request.data
        title = data.get("title")
        text = data.get("text")

        answer = SupportTicketAnswer.objects.create(
            ticket=ticket,
            title = title,
            text=text
        )
        answer.save()

        description = f"Destek talebin cevaplandı!"
        link = BASE_URL

        notification = Notification.objects.create(
            user = ticket.user,
            description=description,
            link=link
        )
        notification.save()

        serializer = SupportTicketAnswerSerializer(answer)

        return Response(serializer.data)


class StatisticsView(APIView):
    """ Kullanıcıların beğeni sayıları, yorum sayıları ve şikayet sayılarının belirtilmesi """
    def get(self,request,*args,**kwargs):
        brand_id = kwargs.get("brand_id")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Invalid brand!")

        complaints = Complaint.objects.filter(brand=brand)

        like_num = 0
        comment_num = 0
        complaint_num = 0

        for comp in complaints:
            like_num += LikeComplaints.objects.filter(complaint=comp).count()
            comment_num += Comment.objects.filter(complaint=comp).count()

        complaint_num = Complaint.objects.filter(brand=brand).count()

        

        instance = HelperNumberofView(like_num,comment_num,complaint_num)

        serializer = InfoNumberSerializer(instance)

        return Response(serializer.data)


class CategoryView(APIView):

    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self,request,*args,**kwargs):

        categories = Category.objects.all()

        serializer = CategorySerializer(categories,many=True)

        return Response(serializer.data)

    def post(self,request,*args,**kwargs):
        
        data = request.data
        name = data.get("name")
        user = request.user

        if not user.is_admin:
            return Response("Sadece admin kategori ekleyip çıkarabilir.")
        
        category = Category.objects.create(
            name=name
        )
        category.save()

        serializer = CategorySerializer(category)

        return Response(serializer.data)


class CategoryDetailView(APIView):

    def get(self,request,*args,**kwargs):
        category_id = kwargs.get("category_id")

        try:
            category = Category.objects.get(id=category_id)
        except Category.DoesNotExist:
            return Response("Kategori bulunamadı")
        
        serializer = CategorySerializer(category)

        return Response(serializer.data)

    def put(self,request,*args,**kwargs):
        category_id = kwargs.get("category_id")

        try:
            category = Category.objects.get(id=category_id)
        except Category.DoesNotExist:
            return Response("Kategori bulunamadı")
        
        name = request.data.get("name")
        category.name = name
        category.save()

        serializer = CategorySerializer(category)

        return Response(serializer.data)

    def delete(self,request,*args,**kwargs):
        category_id = kwargs.get("category_id")

        try:
            category = Category.objects.get(id=category_id)
        except Category.DoesNotExist:
            return Response("Kategori bulunamadı")

        category.delete()

        return Response("Kategori başarıyla silindi")

