from django.db.models import Avg
from brands.models import (
    Brand, 
    Comment, 
    Complaint, 
    Follow, 
    Notification, 
    Requisition,
    LikeComplaints,
    Star
    )
from rest_framework.views import APIView
from rest_framework import permissions
from rest_framework.response import Response
from brands.serializers import (
    BrandSerializer, 
    CommentSerializer, 
    ComplaintSerializer, 
    RequisitionSerializer,
    LikeComplaintsSerializer,
    FollowSerializer,
    StarSerializer,
)
from brands.permissions import IsOwnerOrReadOnly,IsAdminOrReadOnly
from rest_framework import viewsets
from users.models import User
from commons.links import BASE_URL
from rest_framework.parsers import FileUploadParser
from commons.import_export import ImportFile
class PopularByComsView(APIView):
    #detaylı bir algortima yazılacak.
    pass


class PopularComments(APIView):
    def get(self,request):
        comments = Comment.objects.all()[:20]
        serializer = CommentSerializer(comments,many=True)
        return Response(serializer.data)

class BrandViewset(viewsets.ModelViewSet):
    permission_classes = [IsAdminOrReadOnly]
    queryset = Brand.objects.all()
    serializer_class = BrandSerializer


class ComplaintViewset(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    queryset = Complaint.objects.all()
    serializer_class = ComplaintSerializer

class ComplaintView(APIView):
    """ 
    ID bilgisi verilen markaya ait olan tüm şikayetler listelenir.
    """
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self,request,*args,**kwargs):
        brand_id = kwargs.get("brand_id")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Böyle bir marka bulunmamaktadır.")
        
        complaints = Complaint.objects.filter(brand=brand)

        if len(complaints)==0:
            return Response("Bu markaya ait herhangi bir şikayet bulunmamaktadır.")
        
        serializer = ComplaintSerializer(complaints,many=True)

        return Response(serializer.data)
    
    def post(self,request,*args,**kwargs):
        brand_id = kwargs.get("brand_id")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Böyle bir marka bulunmamaktadır")
        
        user = request.user
        data = request.data

        title = data.get("title")
        text = data.get("text")
        image = data.get("image")


        complaint = Complaint.objects.create(
            user=user,
            brand=brand,
            title=title,
            text=text,
            image=image
        )

        complaint.save()
        if brand.user and brand.user != request.user:
            description = f"{request.user} hakkında bir şikayet oluşturdu!"
            link = BASE_URL
            notification = Notification.objects.create(
                user = brand.user,
                description = description,
                link=link,
            )
            notification.save()

        serializer = ComplaintSerializer(complaint)

        return Response(serializer.data)


class ComplaintDetailView(APIView):


    def get(self,request,*args,**kwargs):
        complaint_id = kwargs.get("complaint_id")
        try:
            complaint = Complaint.objects.get(id=complaint_id)
        except:
            return Response("Böyle bir şikayet bulunmamaktadır")
        
        serializer = ComplaintSerializer(complaint)

        return Response(serializer.data)

    def put(self,request,*args,**kwargs):
        complaint_id = kwargs.get("complaint_id")
        data = request.data

        try:
            complaint = Complaint.objects.get(id=complaint_id)
        except Complaint.DoesNotExist:
            return Response("Şikayet bulunamadı!")

        title = data.get("title",False)
        if title:
            complaint.title = title
        
        text = data.get("text",False)
        if text:
            complaint.text = text
        
        image = data.get("image")
        if image:
            complaint.image = image

        situation = data.get("situation",False)
        if situation:
            complaint.situation = situation

        complaint.save()

        serializer = ComplaintSerializer(complaint)
        return Response(serializer.data)
        


class UserComplaintView(APIView):


    def get(self,request,*args,**kwargs):

        user_id = kwargs.get("user_id")

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response("Invalid User!")
        
        complaints = Complaint.objects.filter(user=user)

        if len(complaints) == 0:
            return Response("User don't have any complaint")
        
        serializer = ComplaintSerializer(complaints,many=True)

        return Response(serializer.data)


class RequisitionView(viewsets.ModelViewSet):
    permission_classes = []
    queryset = Requisition.objects.all()
    serializer_class = RequisitionSerializer 

class CommentView(APIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self,request,*args,**kwargs):
        complaint_id = kwargs.get("complaint_id")

        try:
            complaint = Complaint.objects.get(id=complaint_id)
        except Complaint.DoesNotExist:
            return Response("Şikayet bulunamadı!")
        
        comments = Comment.objects.filter(complaint=complaint)
        if len(comments)==0:
            return Response("Şikayet ile ilgili yorum bulunamadı!")

        serializer = CommentSerializer(comments,many=True)

        return Response(serializer.data)
        
    def post(self,request,*args,**kwargs):
        complaint_id = kwargs.get("complaint_id")

        try:
            complaint = Complaint.objects.get(id=complaint_id)
        except Complaint.DoesNotExist:
            return Response("Şikayet Bulunamadı!")
        user = request.user

        data = request.data
        text = data.get("text")
        if not text:
            return Response("Yorum yapmak için bir metin girmelisiniz.")

        comment = Comment.objects.create(
            user=user,
            complaint=complaint,
            text=text
        )
        comment.save()
        brand_user = complaint.brand.user
        if brand_user and brand_user != request.user:
            description = f"{request.user} hakkında açılmış bir şikayete yorum yaptı!"
            link = BASE_URL
            notification = Notification.objects.create(
                user = brand_user,
                description = description,
                link=link,
            )
            notification.save()
        serializer =  CommentSerializer(comment)

        return Response(serializer.data)

class CommentDetailView(APIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self,request,*args,**kwargs):
        comment_id = kwargs.get("comment_id")

        try:
            comment = Comment.objects.get(id=comment_id)
        except Comment.DoesNotExist:
            return Response("Yorum bulunamadı")
        
        serializer = CommentSerializer(comment)
        return Response(serializer.data)

    def put(self,request,*args,**kwargs):
        comment_id = kwargs.get("comment_id")
        try:
            comment = Comment.objects.get(id=comment_id)
        except Comment.DoesNotExist:
            return Response("Böyle bir yorum bulunmamaktadır")
        

        data = request.data
        text = data.get("text",False)


        if text:
            comment.text = text
        comment.save()
        serializer = CommentSerializer(comment)
        return Response(serializer.data)

        
    def delete(self,request,*args,**kwargs):
        comment_id = kwargs.get("comment_id")
        try:
            comment = Comment.objects.get(id=comment_id)
        except Comment.DoesNotExist:
            return Response("Böyle bir yorum bulunmamaktadır")
        
        comment.delete()
        
        return Response("Yorum başarı ile silindi.")

# /like/<complaint_id>/
class LikeView(APIView):

    def get(self,request,*args,**kwargs):
        complaint_id = kwargs.get("complaint_id")

        try:
            complaint = Complaint.objects.get(id=complaint_id)
        except Complaint.DoesNotExist:
            return Response("Marka Bulunamadı!")
        
        likes = LikeComplaints.objects.filter(complaint=complaint)

        if len(likes) == 0:
            return Response("Beğeni yok!")
        
        serializer = LikeComplaintsSerializer(likes,many=True)

        return Response(serializer.data)
    
    def post(self,request,*args,**kwargs):
        user = request.user
        complaint_id = kwargs.get("complaint_id")

        try:
            complaint = Complaint.objects.get(id=complaint_id)
        except Complaint.DoesNotExist:
            return Response("Marka Bulunamadı")
        
        try:
            like = LikeComplaints.objects.get(user=user,complaint=complaint)
            like.delete()
            return Response("Bunu beğenmekten vazgeçtin")

        except LikeComplaints.DoesNotExist:
            LikeComplaints.objects.create(
                user=user,
                complaint=complaint
            ).save()
            description = f"{request.user} şikayetini beğendi!"
            link = BASE_URL + f"brands/complaints/{complaint_id}/"
            if complaint.user != request.user:
                notification = Notification.objects.create(
                    user=user,
                    description = description,
                    link=link
                )
                notification.save()
            
            return Response("Bunu beğendin")

#likes/<user_id>/            
class UserLikesView(APIView):
    
    def get(self,request,*args,**kwargs):
        user_id = kwargs.get("user_id")

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response("Böyle bir kullanıcı bulunmamaktadır.")
        
        likes = LikeComplaints.objects.filter(user=user)

        if len(likes) == 0:
            return Response("Kullanıcının beğendiği bir gönderi bulunmamaktadır")
        
        serializer = LikeComplaintsSerializer(likes,many=True)

        return Response(serializer.data)




# /follow/<brand_id>/
class FollowView(APIView):

    def get(self,request,*args,**kwargs):
        brand_id = kwargs.get("brand_id")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Marka Bulunamadı!")
        
        followers = Follow.objects.filter(brand=brand)

        if len(followers) == 0:
            return Response("Takipçi Yok")
        
        serializer = FollowSerializer(followers,many=True)

        return Response(serializer.data)
    
    def post(self,request,*args,**kwargs):
        user = request.user
        brand_id = kwargs.get("brand_id")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Marka Bulunamadı")
        
        try:
            like = Brand.objects.get(user=user,brand=brand)
            like.delete()
            return Response("Bu firmayı takip etmekten vazgeçtin")

        except Brand.DoesNotExist:
            Brand.objects.create(
                user=user,
                brand=brand
            ).save()
            description = f"{request.user} Markanızı takip etti!"
            link = BASE_URL + f"brands/all-brands/{brand_id}/"
            if brand.user and brand.user != request.user:
                notification = Notification.objects.create(
                    user=user,
                    description = description,
                    link=link
                )
                notification.save()
            
            return Response("Bu markayı takibe aldın.")

class UserFollowView(APIView):
    
    def get(self,request,*args,**kwargs):
        user_id = kwargs.get("user_id")

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response("Böyle bir kullanıcı bulunmamaktadır.")
        
        likes = Follow.objects.filter(user=user)

        if len(likes) == 0:
            return Response("Kullanıcının takip ettiği bir marka bulunmamaktadır")
        
        serializer = FollowSerializer(likes,many=True)

        return Response(serializer.data)


class ImportView(APIView):

    parser_classes = [FileUploadParser]

    def put(self, request, filename, format=None):
        file_obj = request.data['file']
        instance = ImportFile(file_obj,Brand).import_to_instance()
        if instance == "Error":
            return Response("Yükleme sırasında bir hata oluştu. Lütfen tekrar deneyin.")
        
        return Response("Yükleme başarıyla tamamlandı.")

class StarView(APIView):
    
    def get(self,request,*args,**kwargs):
        brand_id = kwargs.get("brand_id")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Marka Bulunamadı")
        
        points = Star.objects.filter(brand=brand).aggregate(Avg('point'))

        return Response(points)

        

    def post(self,request,*args,**kwargs):
        brand_id = kwargs.get("brand_id")
        data = request.data
        value = data.get("point")

        try:
            brand = Brand.objects.get(id=brand_id)
        except Brand.DoesNotExist:
            return Response("Marka Bulunamadı")
        
        user = request.user

        try:
            point = Star.objects.get(brand=brand,user=user)
            point.point = value
        except Star.DoesNotExist:
            point = Star.objects.create(brand=brand,user=user,point=value)
            point.save()
        
        serializer = StarSerializer(point)

        return Response(serializer.data)