from django.urls import path,include,re_path

from rest_framework.routers import DefaultRouter
from . import action_views,search_views,views

router = DefaultRouter()
router.register("requisition",views.RequisitionView,basename="requisition")
router.register("all-brands",views.BrandViewset,basename="all_brands")
router.register("all-complaints",views.ComplaintViewset,basename="all_complaints")

urlpatterns = [
    path('',include(router.urls)),
    re_path(r'^upload/(?P<filename>[^/]+)$', views.ImportView.as_view()),
    #all complaints about spesific brand
    path("complaints/brand/<uuid:brand_id>/",views.ComplaintView.as_view(),name="complaints"),
    #spesific complaint
    path("complaints/<uuid:complaint_id>/",views.ComplaintDetailView.as_view(),name="complaint_detail"),
    #all comments about spesific complaint
    path("complaints/<uuid:complaint_id>/comments/",views.CommentView.as_view(),name="comments"),
    #spesific comment about spesific complaint
    path("complaints/<uuid:complaint_id>/comments/<uuid:comment_id>/",views.CommentDetailView.as_view(),name="comment_details"),
    #likes about spesific complaint
    path("likes/complaint/<uuid:complaint_id>/",views.LikeView.as_view(),name="like_complaint"),
    #likes made by spesific user
    path("likes/user/<uuid:user_id>/",views.UserLikesView.as_view(),name="users_likes"),
    #followers of spesific brand
    path("follow/brand/<uuid:brand_id>/",views.FollowView.as_view(),name="follow_brands"),
    #brand that user follow
    path("follow/user/<uuid:user_id>/",views.UserFollowView.as_view(),name="users_follows"),
    #complaints that spesific user made
    path("complaints/user/<uuid:user_id>/",views.UserComplaintView.as_view(),name="user_complaint"),
    #statistics about brand
    path("statistics/<uuid:brand_id>/",action_views.StatisticsView.as_view(),name="statistics"),
    #the most 100 popular brands
    path("populer-100/",action_views.PopularityView.as_view(),name="popular_100"),
    #popularity among categories
    path("populer-100-by-category/",action_views.CategoryPopularityView.as_view(),name="category_popularity"),
    #create and view support tickets
    path("support-tickets/",action_views.SupportTicketView.as_view(),name="support_ticket"),
    #answer to support tickets
    path("support-ticket-answer/<uuid:ticket_id>/",action_views.SupportTicketAnswerView.as_view(),name="support_ticket_answer"),
    #all categories
    path("categories/",action_views.CategoryView.as_view(),name="all_categories"),
    #spesific category endpoint for updating and deleting
    path("categories/<uuid:category_id>/",action_views.CategoryDetailView.as_view(),name="spesific_category"),
    #search by brand name
    path("search-brand-name/<str:key>/",search_views.SearchBrands.as_view(),name="search_by_brand"),
    #popüler yorumlar
    path("popular-comments/",views.PopularComments.as_view(),name="popular_comments"),
    path("popular-complaints-100/",action_views.PopularComplaints.as_view(),name="popular_complaints_100"),
    #yorum sayılarına göre popüler şikayetler
    path("popular-complaints-by-comments/",views.PopularByComsView.as_view(),name="popular_by_comms"),
    path("give-star/<uuid:brand_id>/",views.StarView.as_view(),name="give_star"),
 ]