from django.urls import path,include
from . import views


urlpatterns = [
    #testleri tamamlandı!!!
    path('register/',views.UserRegisterView.as_view(),name="register"),#email,şifre,şifre tekrar
    path('login/',views.UserLoginView.as_view(),name="login"),#email,şifre
    path('logout/',views.UserLogoutView.as_view(),name="logout"),#post isteği
    path('send-confirmation/',views.SendConfirmationView.as_view(),name="send_confirmation"),#post
    path('confirm-email/<uuid:token>/',views.ConfirmEmailView.as_view(),name="confirm_email"),
    path('change-password/',views.ChangePasswordView.as_view(),name="change_password"),#eski şifre,yeni şifre, şifre tekrar
    path('forgot-password/',views.ForgotPasswordView.as_view(),name="forgot_password"),#email
    path('reset-password/<uuid:token>/',views.PasswordResetView.as_view(),name="reset_password"),
    path("statistics/user/<uuid:user_id>/",views.StatisticsView.as_view(),name="info"),
    path("users/",views.UserProfileView.as_view(),name="profile"),#tüm kullanıcılar
    path("users/<uuid:user_id>/",views.UserProfileDetailView.as_view(),name="profile_detail"),#kullanıcı detay sayfası
    path("notification-settings/<uuid:user_id>/",views.UserNotificationSettingsView.as_view(),name="notification-settings")
    #confirm phone number will be added
]