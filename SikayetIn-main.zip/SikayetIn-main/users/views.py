from .serializers import UserSerializer,InfoNumberSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from django.db import IntegrityError
from .models import User,UserToken
from django.contrib.auth import authenticate,login,logout
from commons.send_mail import send_confirmation_email,send_reset_password_email
from rest_framework import permissions
from django.contrib.auth.hashers import check_password
from brands.models import LikeComplaints,Comment,Complaint,NotificationSettings
from .permissions import IsOwnerOrReadOnly
from brands.serializers import NotificationSettingsSerializer
from commons.helpers import HelperNumberofView
from commons.recaptcha import confirm_captcha


class UserNotificationSettingsView(APIView):

    def get(self,request,*args,**kwargs):
        user = request.user

        try:
            notification_settings = NotificationSettings.objects.get(user=user)
        except NotificationSettings.DoesNotExist:
            notification_settings = NotificationSettings.objects.create(
                user=user,
            )
        
        serializer = NotificationSettingsSerializer(notification_settings)

        return Response(serializer.data)

    def put(self,request,*args,**kwargs):
        user = request.user

        try:
            notification_settings = NotificationSettings.objects.get(user=user)
        except NotificationSettings.DoesNotExist:
            notification_settings = NotificationSettings.objects.create(
                user=user,
            )
        data = request.data
        serializer = NotificationSettingsSerializer(notification_settings,data,partial=True)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            return Response("Invalid Data")

class UserProfileView(APIView):
    
    def get(self,request,*args,**kwargs):
        users = User.objects.all()

        serializer = UserSerializer(users,many=True)

        return Response(serializer.data)


class UserProfileDetailView(APIView):

    permission_classes = [IsOwnerOrReadOnly]

    def get(self,request,*args,**kwargs):
        user_id = kwargs.get("user_id")
        try:
            user = User.objects.get(id=user_id)
        except:
            return Response("Invalid User")
        serializer = UserSerializer(user)
        return Response(serializer.data)

    def put(self,request,*args,**kwargs):
        user_id = kwargs.get("user_id")
        try:
            user = User.objects.get(id=user_id)
        except:
            return Response("Invalid User")
        data = request.data
        serializer = UserSerializer(user,data,partial=True)

        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data)
        else:
            return Response("Invalid Data")



class UserRegisterView(APIView):

    def post(self,request):
        data = request.data
        user_name = data.get("name")
        surname = data.get("surname")
        email = data.get('email')
        password = data.get('password')
        confirmation = data.get('confirmation')
        #captcha test edilmedi
        #captcha_response = data.get("g-recaptcha-response")
        #captcha_result = confirm_captcha(captcha_response)
        #if not captcha_result:
        #    return Response("Recaptcha Onaylanmadı. Hata kodu:  ",captcha_result(confirm_captcha))
        if password and confirmation:
            if password != confirmation:
                return Response("Password should be match with confirmation")
            if not email:
                return Response("You have to provide an email")
            try:
                user = User.objects.create_user(name=user_name,surname=surname,email=email,password=password)
            except IntegrityError:
                return Response("This email is already in use")
            
            serializer = UserSerializer(user)
            login(request,user)
            return Response(serializer.data)
        else:
            return Response("You have to provide a password and confirm that password")

class UserLoginView(APIView):
    """ Login User with session based authentication """
    
    def post(self,request):
        data = request.data
        email = data.get('email')
        password = data.get('password')
        if email and password:
            user = authenticate(email=email,password=password)
            if user is not None:
                login(request,user)
                serializer = UserSerializer(user)
                return Response(serializer.data)
            else:
                return Response("There is no such user")
        else:
            return Response("Email and password should be provided!")


class UserLogoutView(APIView):
    """ Logout the user """

    permission_classes = [permissions.IsAuthenticated]

    def post(self,request):
        try:
            logout(request)
        except:
            return Response("Unfortunately an error occured!")
        return Response("You have Logged out Successfully!")

class SendConfirmationView(APIView):

    permission_classes = [permissions.IsAuthenticated]

    def post(self,request):
        user = request.user

        if user.is_email_confirmed:
            return Response("Your account has already been confirmed!")
        
        token_objs = UserToken.objects.filter(user=user)

        if token_objs:
            token_objs.delete()
        
        email = user.email

        token_obj = UserToken.objects.create(user=user)

        send_confirmation_email(email,token_obj.token)

        return Response("We have sent you a confirmation email")


class ConfirmEmailView(APIView):

    def get(self,request,*args,**kwargs):
        token = kwargs.get('token')
        try:
            token_obj = UserToken.objects.get(token=token)
        except UserToken.DoesNotExist:
            return Response("Invalid Token")

        if token_obj.is_valid:
            user = token_obj.user
            user.confirm_email = True
            user.save()
            return Response("Your account has been verified!")
        else:
            return Response("This token is not valid. Time is expired!")


class ChangePasswordView(APIView):
    """ Change User Password """
    permission_classes = [permissions.IsAuthenticated]

    def post(self,request):
        data = request.data
        user = request.user
        old_password = data.get('old_password')
        new_password = data.get('new_password')
        confirmation = data.get('confirmation')
        
        if new_password and confirmation:
            if new_password != confirmation:
                return Response("Passwords does not match!")
            if old_password:
                user_password = user.password
                is_match = check_password(old_password,user_password)
                if not is_match:
                    return Response("Your old password is not match with your password")
                user.set_password(new_password)
                user.save()                
                return Response("Your password has been updated")
            else:
                return Response("Please provide your old password")
        else:
            return Response("Please provide a new password and a confirmation!")



class ForgotPasswordView(APIView):

    """ Forgot password email sender """


    def post(self,request):
        data = request.data
        email = data.get("email")
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response("Invalid Email address")

        old_token_objs = UserToken.objects.filter(user=user)

        if old_token_objs:
            old_token_objs.delete()
        
        token_obj = UserToken.objects.create(user=user)

        send_reset_password_email(email,token_obj.token)

        return Response("Password reset e-mail has been sent!")

         

class PasswordResetView(APIView):
    """ Reset the password for the user who forgot their passwords """

    def get(self,request,*args,**kwargs):
        token = kwargs.get("token")
        if token:
            try:
                token_obj = UserToken.objects.get(token=token) 
            except UserToken.DoesNotExist:
                return Response("Invalid Token")
        else:
            return Response("Token Should be provided")

        if token_obj.is_valid:
            
            user = token_obj.user
            serializer = UserSerializer(user)
            return Response(serializer.data)
        else:
            token_obj.delete()
            return Response("This Token is expired!")
    
    def post(self,request,*args,**kwargs):
        data = request.data
        token = kwargs.get("token")
        try:
            user = User.objects.get(id=data.get('id'))
        except:
            return Response("There is no such user in our database!")
        password = data.get("password")
        confirmation = data.get("confirmation") 

        if password and confirmation:
            if password != confirmation:
                return Response("Password must match!")
            user.set_password(password)
            user.save()
            UserToken.objects.get(token=token).delete()
            serializer = UserSerializer(user)
            return Response(serializer.data)
        else:
            return Response("You should provide password and confirmation to us!")



class StatisticsView(APIView):
    """ Kullanıcıların beğeni sayıları, yorum sayıları ve şikayet sayılarının belirtilmesi """
    def get(self,request,*args,**kwargs):
        user_id = kwargs.get("user_id")

        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response("Invalid User!")

        like_num = LikeComplaints.objects.filter(user=user).count()
        comment_num = Comment.objects.filter(user=user).count()
        complaint_num = Complaint.objects.filter(user=user).count()

        instance = HelperNumberofView(like_num,comment_num,complaint_num)

        serializer = InfoNumberSerializer(instance)

        return Response(serializer.data)