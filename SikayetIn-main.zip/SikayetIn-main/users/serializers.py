from rest_framework import serializers
from rest_framework.reverse import reverse
from users.models import User

class UserSerializer(serializers.ModelSerializer):
    """ Serialize Base User İnformation """
    url = serializers.SerializerMethodField(read_only=True)
    class Meta:
        model = User
        fields = "__all__"
    
    def get_url(self,obj):
        request = self.context.get("request")
        return reverse("profile_detail",kwargs={"user_id":obj.id},request=request)
    
class InfoNumberSerializer(serializers.Serializer):
    like_num = serializers.IntegerField(read_only=True)
    comment_num = serializers.IntegerField(read_only=True)
    complaint_num = serializers.IntegerField(read_only=True)