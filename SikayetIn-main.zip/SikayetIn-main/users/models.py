from django.db import models
from django.db import models
from django.contrib.auth.models import BaseUserManager,AbstractBaseUser,PermissionsMixin
import uuid
from django.utils import timezone
#signal imports
from django.db.models.signals import post_save
from django.dispatch import receiver

from commons.send_mail import send_confirmation_email

from django.utils import timezone

class UserManager(BaseUserManager):
    """ Veri tabanındaki tablolarla ilişki kurabilmek için
    managerlar yardımıyla objeler oluşturma
     """
    def create_user(self,name,surname,email,password=None,is_staff=False,is_active=True,is_admin=False):
        if not email:
            raise ValueError("User must have an email")
        if not password:
            raise ValueError("User must have a password")
        user_obj = self.model(
            email=self.normalize_email(email),
        )

        user_obj.set_password(password)

        user_obj.admin = is_admin
        user_obj.staff = is_staff 
        user_obj.active = is_active
        user_obj.name = name
        user_obj.surname = surname

        user_obj.save(using=self._db)

        return user_obj
    
    def create_staffuser(self,email,password):
        user = self.create_user(email=email,password=password,is_staff=True)
        return user
    
    def create_superuser(self,email,password):
        user = self.create_user(email=email,password=password,is_admin=True,is_staff=True)
        return user

class User(AbstractBaseUser,PermissionsMixin):
    """ 
    Django ile birlikte default olarak gelen username 
    ile authentication'ı email ile yapmak için AbstractBaseUser yeniden yazılması
    """
    id = models.UUIDField(
        default=uuid.uuid4,
        primary_key=True,
        editable=False
    )  
    email = models.EmailField(max_length=255,unique=True)
    phone_number = models.CharField(max_length=128,blank=True,null=True)#değiştirilecek
    username=models.CharField(max_length=255)
    name = models.CharField(max_length=255,blank=True,null=True)
    surname = models.CharField(max_length=255,blank=True,null=True)
    photo = models.ImageField(upload_to="profile_photo/",blank=True,null=True)
    active = models.BooleanField(default=True)
    staff = models.BooleanField(default=False)
    admin = models.BooleanField(default=False)
    confirm_email = models.BooleanField(default=False)
    confirm_phone_number = models.BooleanField(default=False)
    timestamp = models.DateTimeField(auto_now_add=True)
    editor = models.BooleanField(default=False)
    blogger = models.BooleanField(default=False)
    #database ile olan ilişkileri yönetmek için managerlar kullanılır
    objects = UserManager()
    cinsiyet = models.CharField(max_length=100,null=True,blank=True)
    ogrenim_durumu = models.CharField(max_length=100,null=True,blank=True)
    medeni_durum = models.CharField(max_length=100,blank=True,null=True)
    hane_geliri = models.CharField(max_length=100,blank=True,null=True)
    sehir = models.CharField(max_length=100,blank=True,null=True)
    calisma_durumu = models.CharField(max_length=100,blank=True,null=True)
    dogum_yili = models.CharField(max_length=100,blank=True,null=True)

    USERNAME_FIELD = "email"#Login için hangi alan bakılacak

    #email ile password default olarak gerekli
    REQUIRED_FIELDS = []

    def __str__(self) -> str:
        return self.email
    
    def get_full_name(self):
        return self.name + self.surname 
    
    @property
    def is_email_confirmed(self):
        return self.confirm_email
    
    @property
    def is_phonenumber_confirmed(self):
        return self.confirm_phone_number

    @property
    def is_active(self):
        return self.active

    @property
    def is_superuser(self):
        return self.admin
    
    @property
    def is_staff(self):
        return self.staff
    
    @property
    def is_blogger(self):
        return self.blogger

    
class Category(models.Model):
    id = models.UUIDField(default=uuid.uuid4,primary_key=True,editable=False)
    name = models.CharField(max_length=300,unique=True)

    def get_all_categories(self):
        return self.objects.all()
    
    def __str__(self) -> str:
        return self.name


class UserToken(models.Model):
    id = models.UUIDField(default=uuid.uuid4,primary_key=True,editable=False)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    token = models.UUIDField(default=uuid.uuid4,editable=False)
    created = models.DateTimeField(auto_now_add=True)
    experation_date = models.IntegerField(default=1)

    def __str__(self) -> str:
        return str(self.token)
    
    def get_token(self):
        return self.token

    @property
    def is_valid(self):
        date = timezone.now() - self.created
        day = date.days
        return day<self.experation_date


#kullanıcı profilleri oluşturulduğunda herkese bir email doğrulama maili gönderilecek.
@receiver(post_save,sender=User)
def receiver_send_confirmation_mail(sender,instance,created,*args,**kwargs):
    if created:
        token = UserToken.objects.create(user=instance)
        token.save()
        send_confirmation_email(instance.email,token)
    